const xValues = [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150];
const yValues = [7, 8, 8, 9, 9, 9, 10, 11, 14, 14, 15];

new Chart(document.getElementById("line"), {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: "rgba(0,0,255,0.1)",
      borderColor: "rgba(0,0,255,1.0)",
      data: yValues,
      fill: false,
    }]
  },
  options: {
    scales: {
      x: {
        title: {
          display: true,
          text: 'X Axis Label'
        }
      },
      y: {
        title: {
          display: true,
          text: 'Y Axis Label'
        }
      }
    },
    plugins: {
      legend: {
        display: false
      }
    }
  }
});
